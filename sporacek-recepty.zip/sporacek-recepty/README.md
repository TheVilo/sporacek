# šporáček — databáza receptov a obsahu

Repozitár slúži ako **jeden zdroj pravdy** pre recepty šporáčka.
Dnes z neho čerpá sociálny obsah (Stories, FB/IG), neskôr web a aplikácia.

## Ako to funguje

```
CLAUDE.md          ← mozog: pravidlá, tón, týždenný postup
suroviny.md        ← číselník surovín (jednotné názvy — kritické)
znalostna-baza/    ← brand manuál, obsahová stratégia
recepty/           ← jeden súbor = jeden recept
tydne/             ← výstup týždňa (leták → recepty → nákup → úspora)
```

Fotky **nie sú v repe** — recept drží len odkaz (`foto_url`).
Súbor fotky sa volá podľa `id` receptu (napr. `kremove-kuracie-rizoto-sampinony.jpg`).

## Týždenný postup

1. Otvor nový chat s Claude (repo pripojené cez GitHub konektor alebo Claude Code).
2. Povedz: **„Načítaj CLAUDE.md a recepty. Tu je leták."** + nahraj leták (PDF/screenshot).
3. Claude vráti:
   - zoznam akciových produktov
   - 5 obedov (Po–Pi, pre 2 osoby) — prednostne z existujúcej databázy
   - cenu za porciu, nákupný zoznam, celkovú úsporu
   - `foto_prompt` ku každému jedlu
   - texty do Stories
4. Fotky vygeneruj cez nanobananu podľa `foto_prompt`, ulož pod `id` receptu, doplň `foto_url`.
5. Commitni nové recepty a týždeň.

## Prečo je to takto postavené

- **Recept = trvalý** (suroviny, postup, tagy, fotka). Nerobí sa dvakrát.
- **Cena = dočasná** (snapshot podľa akcie). Prepočíta sa každý týždeň.
- **Leták = jednorazový vstup.** Automatický zber akcií stavia programátor — tu ho neriešime.
- **Tagy + číselník surovín** umožňujú rýchlo hľadať: „čo navarím z akciových kuracích stehien?"
